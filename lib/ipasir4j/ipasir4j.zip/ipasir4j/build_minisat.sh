
#########################################
# BUILD THE C++ PART (SAT SOLVER PART)  #
#########################################

cd cppsrc/minisat220

make
mv libipasirminisat* ipasirminisatglue.o ..
cd ..

# locate the java directory
JAVA_HOME_VAR=`if [ x"$JAVA_HOME" = x ]; then readlink -f /usr/bin/java | sed "s:jre/bin/java::" | sed "s:bin/java::"; else echo "$JAVA_HOME"; fi`
echo "Java location: " $JAVA_HOME_VAR

# compile the JNI code
g++ -o libipasir4j.so -shared -lc -fPIC ipasir4j_Ipasir4jNative.cpp ipasirminisatglue.o -I$JAVA_HOME_VAR/include/ -I$JAVA_HOME_VAR/include/linux/ -L. -lipasirminisat220

# move the shared libraries
mv libipasirminisat* ../
mv libipasir4j.so ../
cd ..

#########################################
# BUILD THE Java PART (Java Interface)  #
#########################################
#echo "Building java parts ..."
#javac -d . src/ipasir4j/*.java
#jar -cf ipasir4j.jar ipasir4j/Ipasir4j*
