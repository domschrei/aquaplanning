rm -fr cppsrc/picosat-961
cd cppsrc/minisat220
make clean
cd ../..
rm -f cppsrc/*.o cppsrc/*.so
rm -fr ipasir4j
rm -f *.so *.jar *.o *.a
